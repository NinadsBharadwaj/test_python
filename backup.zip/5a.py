import re
 
def chk_phone_no(num):
    for i in range(len(num)):
        if i ==3 and i==7:
            if num[i]!="-":
                return False
        else:
            if num[i].isdigit()==False:
                return False
        return True

def is_ph_no(num):
    ph_no_pattern=re.compile(r'^\d{3}-\d{3}-\d{4}$')
    if ph_no_pattern.match(num):
        return True
    else:
        return False

num=input("Enter Phone number:")
print("Without re:")
if chk_phone_no(num):
    print("Valid")
else:
    print("Invalid:")


print("With re:")
if is_ph_no(num):
    print("Valid")
else:
    print("Invalid:")
