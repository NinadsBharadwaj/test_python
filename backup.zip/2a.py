def f(n):
    if n==1:
        return 0
    elif n==2:
        return 1
    else :
        return f(n-1)+f(n-2)

n=int(input("Enter value of n:"))
list=[]
for i in range(1,n+1):
    list.append(f(i))
print("Fibonacci Sequence upto",n,"is",list)