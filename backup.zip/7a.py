import math
class shape():
    def __init__(self):
        self.area=0
        self.name=""
    def showarea(self):
        print("The are of ",self.name," is ",self.area," units")
class circle(shape):
    def __init__(self,radius):
        self.area=0
        self.name="Circle"
        self.radius=radius
    def calcarea(self):
        self.area=math.pi*self.radius*self.radius
class rectangle(shape):
    def __init__(self,length,breadth):
        self.area=0
        self.name="Rectangle"
        self.length=length
        self.breadth=breadth
    def calcarea(self):
        self.area=self.length*self.breadth

class triangle(shape):
    def __init__(self,base,height):
        self.area=0
        self.name="Triangle"
        self.base=base
        self.height=height
    def calcarea(self):
        self.area=0.5*self.base*self.height


c1=circle(5)
c1.calcarea()
c1.showarea()

c2=rectangle(2,3)
c2.calcarea()
c2.showarea()

c3=triangle(2,3)
c3.calcarea()
c3.showarea()