import sys
import os.path

fname=input("Enter File name:")
if not os.path.isfile(fname):
    print("File Not Found:")
    sys.exit(0)
in_file=open(fname,'r')
linelist=in_file.readlines()
for i in range(len(linelist)):
    print(i+1,":",linelist[i])

word=input("Enter word to find:")
cnt=0
for line in linelist:
    cnt+=line.count(word)

print("Words are",cnt)