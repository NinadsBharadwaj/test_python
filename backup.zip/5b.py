import re

ph_regex=re.compile(r'\+\d{12}')
email_regex=re.compile(r'[A-Z0-9a-z_.]+@[A-Za-z0-9]+\.[A-Z|a-z]{2,}')


with open('1.txt','r') as f:
    for lines in f:
        matches=ph_regex.findall(lines)
        for match in matches:
            print(match)

        matches=email_regex.findall(lines)
        for match in matches:
            print(match)
                