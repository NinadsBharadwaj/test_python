class employee:
    def __init__(self):
        self.id=""
        self.Name=""
        self.department=""
        self.salary=0
    def getempdetails(self):
        self.id=input("Enter id")
        self.Name=input("Enter name")
        self.department=input("Enter department")
        self.salary=int(input("Enter salary"))

    def showempdetails(self):
        print("Employee details are:")
        print("ID:",self.id)
        print("Name:",self.Name)
        print("department:",self.department)
        print("Salary:",self.salary)
    
    def updtsalary(self):
        self.updtsalary=int(input("Enter updated salary:"))
        print("Updated salry is:",self.updtsalary)
    
e1=employee()
e2=employee()
e1.getempdetails()
e2.getempdetails()
e1.showempdetails()
e2.showempdetails()
e1.updtsalary()
e2.updtsalary()