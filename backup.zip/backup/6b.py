import sys
import os
import pathlib
import zipfile

dirName=input("Enter directory name:")
if not os.path.isdir(dirName):
    print("Not found")
    sys.exit(0)
curdirectory=pathlib.Path(dirName)
 
with zipfile.ZipFile("backup.zip",mode="w") as archive:
    for file_path in curdirectory.rglob("*"):
        archive.write(file_path,arcname=file_path.relative_to(curdirectory))
if os.path.isfile("backup.zip"):
    print("File is archived")
else:
    print("Error")