import random

def merge_sort(lst):
    if len(lst)>1:
        mid=len(lst)//2
        left=lst[:mid]
        right=lst[mid:]
        merge_sort(left)
        merge_sort(right)
        i=j=k=0
        while i<len(left) and j<len(right):
            if left[i]<right[j]:
                lst[k]=left[i]
                i+=1
            else:
                lst[k]=right[j]
                j+=1
            k+=1
        while i<len(left):
            lst[k]=left[i]
            i+=1
            k+=1
        while j<len(right):
            lst[k]=right[j]
            j+=1
            k+=1
    return lst

def insertion_sort(arr):
    for i in range(1,len(arr)):
        key=arr[i]
        j=i-1
        while j>=0 and key<arr[j]:
            arr[j+1]=arr[j]
            j-=1
        arr[j+1]=key
    return arr

mylist=[]
for i in range(10):
    mylist.append(random.randint(0,999))
print("Unsorted List is:")
print(mylist)
print("Sorted List using insertion Sort is:")
print(insertion_sort(mylist))


mylist=[]
for i in range(10):
    mylist.append(random.randint(0,999))
print("Unsorted List is:")
print(mylist)
print("Sorted List using merge Sort is:")
print(merge_sort(mylist))
