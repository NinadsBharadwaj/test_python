m1=int(input("Enter marks 1:"))
m2=int(input("Enter marks 2:"))
m3=int(input("Enter marks 3:"))
Z=True
while Z==True:
    if m1<=m2 and m1<=m3:
        print("Average is:",(m2+m3)/2)
    elif m2<=m1 and m2<=m3:
        print("Average is:",(m1+m3)/2)
    else:
        print("Average is:",(m1+m2)/2)
    x=input("Try Again Y/N")
    if x=="N":
        Z=False
