str1=input("Enter 1st string:").lower()
str2=input("Enter 2nd string:").lower()
if len(str2)<=len(str1):
    long=len(str1)
    short=len(str2)
else:
    long=len(str2)
    short=len(str1)
cnt=0
for i in range(short):
    if str1[i]==str2[i]:
        cnt+=1

print("Similarity is",cnt/long)