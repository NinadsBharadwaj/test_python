val=input("enter the value:")
if val==val[::-1]:
    print("Its a palindrome:")
else:
    print("Its not a palindrome:")

for i in range(len(val)):
    if val.count(str(i))>0:
        print("The value ",str(i),"appears",val.count(str(i)),"times")