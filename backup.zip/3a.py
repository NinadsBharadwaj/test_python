sentence=input("enter a sentence")
list=sentence.split(" ")
print("Number of words is: ",len(list))
digcnt=locnt=upcnt=0
for ch in sentence:
    if '0'<=ch<='9':
        digcnt+=1
    elif 'A'<=ch<='Z':
        upcnt+=1
    elif 'a'<=ch<='z':
        locnt+=1
print(digcnt,"<--digits",locnt,"<--lower case letters: uppercase letters -->",upcnt)
      