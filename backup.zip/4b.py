def roman2decima(rom):
    rom_dict={'I':1,'V':5,'X':10,'L':20,'C':100,'D':500,"M":1000}
    romback=list(rom)[::-1]
    value=0
    right=rom_dict[romback[0]]
    for numeral in romback:
        left=rom_dict[numeral]
        if left<right:
            value-=left
        else:
            value+=left
        right=left
    return value

    str=input("Enter in roman:").upper()
    print(roman2decima(str))